package com.example.reto5.Repository.CrudRepository;

import com.example.reto5.entities.Costume;
import org.springframework.data.repository.CrudRepository;

public interface CostumeCrudRepository extends CrudRepository<Costume, Integer> {

}

package com.example.reto5.Repository.CrudRepository;

import com.example.reto5.entities.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminCrudRepository extends CrudRepository<Admin, Integer> {

}

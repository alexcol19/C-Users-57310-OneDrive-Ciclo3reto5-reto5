package com.example.reto5.Repository.CrudRepository;

import com.example.reto5.entities.Score;
import org.springframework.data.repository.CrudRepository;

public interface ScoreCrudRepository extends CrudRepository<Score, Integer> {

}

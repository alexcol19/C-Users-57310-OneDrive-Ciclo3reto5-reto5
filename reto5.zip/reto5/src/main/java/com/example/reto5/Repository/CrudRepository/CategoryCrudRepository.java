package com.example.reto5.Repository.CrudRepository;

import com.example.reto5.entities.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> {

}
